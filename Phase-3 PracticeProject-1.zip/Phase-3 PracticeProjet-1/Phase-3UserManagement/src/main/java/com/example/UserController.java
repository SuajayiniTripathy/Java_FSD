package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	@Autowired
	UserService ps;
	
	@GetMapping("/getall")
	public ModelAndView getAllUsers()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("show");
		
		List  users= ps.getAllUsers();
		mv.addObject("msg",users);
		return mv;
	}
	@PostMapping(value="/addproduct")
	public String addUser(User user)
	{
		 ps.addUser(user);
		
		 return "redirect:/index.jsp";
	}
	
@GetMapping("/showadditionform")
public String showAdditionForm()
{
	return "add_users";
}

@GetMapping("/deleteuser")
public String deleteUser(@RequestParam("uid") int UserID)
{
	ps.deleteUser(UserID);
	return "redirect:/index.jsp";
}
@GetMapping("/backtoindex")
public String backToIndexPage()
{
	return "redirect:/index.jsp";
}
}