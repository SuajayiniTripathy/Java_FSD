package com.example;

import java.util.List;

import org.hibernate.usertype.UserType;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class UserServiceImpl  implements UserService {
	@Autowired
	UserType userDAO;
	public List getAllUser() {
		return UserType.getAllUser();
		
	}

	public boolean addUser(User user) {
		userDAO.addUser(user);
		return true;
	}

	public boolean deleteUser(int userId) {
		return ((UserService) userDAO).deleteUser(userId);
		
	}
}

