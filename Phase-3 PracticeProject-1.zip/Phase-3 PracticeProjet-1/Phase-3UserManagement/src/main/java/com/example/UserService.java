package com.example;

import java.util.List;
import java.com.example.User;
public interface UserService {
	List  getAllProducts();
	
	 boolean addProduct(User user);
	 
	  boolean deleteProduct(int productId);

	List getAllUsers();

	boolean addUser(User user);

	boolean deleteUser(int userID);
	  
}


