package com.example;

import java.util.List;

import javax.management.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.SelectionQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class UserDAOImpl  implements UserDAO {
	@Autowired
	SessionFactory factory;

	@Transactional
	@SuppressWarnings({ "unchecked", "finally" })
	public List getAllUser() {
		List user = null;
		try
		{
			 
			Session session=factory.getCurrentSession();
			Query q=(Query) session.createQuery("from User");
			user= ((SelectionQuery) q).getResultList();
		    
		}
		catch (Exception e)
		{}
		finally
		{
			return user;
		}
		
	}
	
	@Transactional
	public boolean addUser(User user) {
		
		Session session=factory.getCurrentSession();
		session.save(user);
		return true;
	}
 
	@Transactional 
	public boolean deleteUser(int UserId) {
		
		Session session=factory.getCurrentSession();
		User p=session.get(User.class, UserId);
		session.delete(p);
		
		return true;
	}


}
