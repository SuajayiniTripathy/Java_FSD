package com.example;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table


public class User {
	
	@Override
	public String toString() {
		return "Users [UserId=" + userId + ", userName=" + userName + ", age=" + age
				+ ", city=" + city + "]";
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private int userId;
	@Column(name="USER_NAME")
	private String userName;
	@Column(name="age")
	private int age;
	@Column(name="cirty")
	private String city;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String getcity() {
		return city;
	}
	public void setProductType(String city) {
		this.city = city;
	}
	public int getage() {
		return age;
	}
	public void setage(int  age) {
		this.age = age;
	}
	

}
