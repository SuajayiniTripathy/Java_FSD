package com.example;
import java.awt.List;
public interface UserDAO {
	java.util.List  getAllUser();
	
	 boolean addUser(User user);
	 
	  boolean deleteUser(int UserId);

}
