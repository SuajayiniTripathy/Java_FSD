package FileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class Writefile {

	public static void main(String[] args) {
		String data ="Hi! this is Suajyini from Odisha";
		try {
			FileWriter output= new FileWriter("data.txt");
			output.write(data);
		    System.out.println("data is written sucessfully");
		    output.close();
			
		} catch (IOException ex) {
			System.out.println("file write Error");
		}
		
		
		
		
		
	}

}
