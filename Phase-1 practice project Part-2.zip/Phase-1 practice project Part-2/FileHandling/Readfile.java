package FileHandling;

import java.io.FileReader;
import java.io.IOException;

public class Readfile {

	public static void main(String[] args) {
		char[] data= new char[100];
		
		try {
			FileReader input = new FileReader("data.txt");
			input.read(data);
			System.out.println("dat recived from a file");
			System.out.println(data);
			input.close();
		} catch (IOException ex) 
		{  
			System.out.println("file read Error");
		}
	}}
			
		
		
		
		
		

	


