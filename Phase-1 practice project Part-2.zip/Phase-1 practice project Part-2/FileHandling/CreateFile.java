package FileHandling;

import java.io.File;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) {
		File Myfile =new File("data.txt");
		try {
			if (Myfile.createNewFile()) {
				System.out.println("File is created");
				
			}
			else {
				System.out.println("file creation error");
			}
		} catch (IOException e) {
			System.out.println("file error");
			e.printStackTrace();
		}

	}

}
