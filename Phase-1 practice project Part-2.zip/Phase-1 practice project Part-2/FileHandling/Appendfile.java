package FileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class Appendfile {

	public static void main(String[] args) {
		String data =("I have done my graduation in KIIT university");
         try {
			FileWriter output= new FileWriter ("data.txt");
			output.write(data);
			System.out.println("data appended sucesssfully");
			output.close();
		} catch (IOException ex) {
			System.out.println("File appended error");
			
		}
         
	}

}
