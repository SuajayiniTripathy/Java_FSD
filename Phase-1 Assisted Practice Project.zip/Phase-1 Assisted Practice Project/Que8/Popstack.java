package Que8;

import java.util.Stack;

public class Popstack {

	public static void main(String[] args) {
		Stack<Integer> amount = new Stack<Integer>();
		amount.push(1000);
		amount.push(2000);
		amount.push(3000);
		amount.push(5000);
		amount.push(100);
		System.out.println("Stack:"+ amount);
		amount.pop() ;
		System.out.println("Stack after pop" + amount);

	}

}
