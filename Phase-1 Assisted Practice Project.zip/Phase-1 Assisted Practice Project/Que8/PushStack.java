package Que8;

import java.util.Stack;

public class PushStack {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(1000);
		stack.push(2000);
		stack.push(3000);
		stack.push(5000);
		stack.push(100);
		System.out.println(stack);

	}

}
