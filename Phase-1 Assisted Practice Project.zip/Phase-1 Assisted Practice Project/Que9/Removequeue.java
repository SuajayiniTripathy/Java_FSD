package Que9;

import java.util.LinkedList;
import java.util.Queue;

public class Removequeue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Queue <Integer> Aq =new LinkedList<Integer>();
		    Aq.add(1234);
		    Aq.add(256783);
		    Aq.add(12345677);
		    Aq.add(45678);
		    System.out.println(Aq);
		    Aq.remove();
		    System.out.println("Queue afrer remove elements:" + Aq);
	}

}
