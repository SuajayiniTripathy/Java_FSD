package Que9;

import java.util.LinkedList;
import java.util.Queue;

public class AddQueue {

	public static void main(String[] args) {
	    Queue <Integer> Aq =new LinkedList<Integer>();
	    Aq.add(1234);
	    Aq.add(256783);
	    Aq.add(12345677);
	    Aq.add(45678);
	    System.out.println(Aq);
	    Aq.add(100);
	    System.out.println("afer adding elemnt : " + Aq);
	}

}
