package virtualkeyForRepositoy;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Displayfile {

	public void displayfile() throws IOException {
		
		String path="//C:\\Users\\KIIT\\Desktop\\Assessment//";
		File f=new File(path);
		
		File filenames[]=f.listFiles();
		for(File ff:filenames) {
			System.out.println(ff.getName());
		}
		
	}




}

