package virtualkeyForRepositoy;

import java.io.IOException;
import java.util.Scanner;

public class MainProgram {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Createfile Cf=new Createfile();
		Deletefile Df=new Deletefile();
		Searchfile Sf= new Searchfile();
		Displayfile Dsf= new Displayfile(); 
		
		
		while(true) {
			System.out.println("1. Display all files..\n2. add delete search\n3. Exit");
			System.out.println("enter your option");
			int opt1= sc.nextInt();
			switch (opt1){
				case 1 :
				{
					Dsf.displayfile();
					break;
				}
				case 2 :boolean loop=true;
					while(loop) {
						System.out.println("1. Addfile\n2. Deletefile\n3. Searchfile\n4. Main Menu\n");
						System.out.println("Enter your Sub option for switch case");
						int opt2 = sc.nextInt();
						switch(opt2) {
						case 1 : Cf.createFile();
						break;
						case 2 : Df.dltfile();
						break;
						case 3 : Sf.schfile();
						break;
						case 4 : loop=false;
						break;
						}
					
					}
					break;
			
				case 3 : System.exit(0);
					break;
			}
			
		}
		

	}

	
		
}

	
		
		



