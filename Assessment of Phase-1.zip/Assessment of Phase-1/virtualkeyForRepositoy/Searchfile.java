package virtualkeyForRepositoy;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Searchfile {

	public void schfile() throws IOException {
		
		String path ="//C:\\Users\\KIIT\\Desktop\\Assessment//";
				
					Scanner sc1=new Scanner(System.in);
					System.out.println("enter the filename");
					String filename=sc1.next();
					String finalpath=path+filename;
					File f=new File(finalpath);
					int flag=0;
					File filenames[]=f.listFiles();
					for(File ff:filenames) {
						if(ff.getName().equals(filename)) {
							flag=1;
							break;
						}
						else {
							flag=0;
						}
					
					}
					
					
					if(flag==1) {
						System.out.println("file is found");
					}
					else {
						System.out.println("file is not found");
					}
					
				}

			}

	


