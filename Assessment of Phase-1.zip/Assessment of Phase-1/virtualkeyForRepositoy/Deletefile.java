package virtualkeyForRepositoy;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Deletefile {

	public void dltfile()throws IOException {
		
	      String path=("//C:\\Users\\KIIT\\Desktop\\Assessment//");
		 
			Scanner sc1=new Scanner(System.in);
			System.out.println("enter the filename");
			String filename=sc1.next();
			String finalpath=path+filename;
			File f=new File(finalpath);
			f.delete();
			System.out.println("file gets deleted");
			

	}


		
	}

	


		
	

