import java.util.*;

public class colllections {

	public static void main(String[] args) {
		
		// ArrayList 
		System.out.print("ArrayList :> ");
		ArrayList<String> name=new ArrayList<String>();
		name.add("Sita");
		name.add("Gita");
		name.add("Rita");
		System.out.println(name);
		
		// Vector
		System.out.print("Vector  :> ");
		Vector<Integer> vec=new Vector();
		vec.addElement(5);
		vec.addElement(10);
		vec.addElement(15);
		System.out.println(vec);
		 
		// LinkedList 
		System.out.print("Linked List   :> ");
		LinkedList<Integer> l1=new LinkedList();
		l1.add(5);
		l1.add(6);
		l1.add(7);
		System.out.println(l1);
		
		// Hashset
		System.out.print("HashSet  :> ");
		HashSet<Integer> h1=new HashSet();
		h1.add(10);
		h1.add(20);
		h1.add(30);
		System.out.println(h1);
		
		// LinkedHashSet
		System.out.print("LinkedHashSet  :> ");
		LinkedHashSet<Integer> lh=new LinkedHashSet();
		lh.add(23);
		lh.add(24);
		lh.add(25);
		System.out.println(lh);
	}

}
