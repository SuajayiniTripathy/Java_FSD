package practicepackage4;

public class persondetails1 {

 persondetails1() {
		int salary = 50000,bonus = 5000;
		System.out.println("final amount is :" +(bonus+salary));

	}

}
