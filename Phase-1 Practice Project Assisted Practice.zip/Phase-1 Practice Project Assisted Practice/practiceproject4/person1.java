package practicepackage4;

public class person1 {

	public static void main(String[] args) {
		persondetails1 persondetail=new persondetails1();

	}

}
