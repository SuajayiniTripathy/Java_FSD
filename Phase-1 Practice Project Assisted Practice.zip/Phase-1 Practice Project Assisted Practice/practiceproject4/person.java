///parameterized constructor
package practicepackage4;

public class person {

	public static void main(String[] args) {
		persondetails persondetail=new persondetails(50000,4500);
		
	}

}


	


