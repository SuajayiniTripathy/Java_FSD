///parameterized constructor
package practicepackage4;

public class persondetails {

	persondetails(int salary, int bonus) {
		System.out.println("final amount is :" +(bonus+salary));
	}


}
