package practiceProject8;
import java.util.* ;
public class StringToStringBuffer {
	public static void main(String[] args) {
	System.out.println("Creating StringBuffer");
	StringBuffer s=new StringBuffer("This is Sujayini Tripathy!");
	s.append("I m from odisha") ;
	System.out.println(s);
	String str = "hello";
	StringBuffer sbr = new StringBuffer(str); 
    sbr.reverse(); 
    System.out.println("String to StringBuffer");
    System.out.println(sbr); 
}
}