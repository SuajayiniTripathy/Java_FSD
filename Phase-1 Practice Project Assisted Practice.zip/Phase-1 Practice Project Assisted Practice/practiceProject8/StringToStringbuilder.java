package practiceProject8;

public class StringToStringbuilder {

	public static void main(String[] args) {
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);
		System.out.println(sb1.insert(1, "Welcome"));
		System.out.println(sb1.reverse());
		String str = "Hello"; 
		StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
	}

	}


