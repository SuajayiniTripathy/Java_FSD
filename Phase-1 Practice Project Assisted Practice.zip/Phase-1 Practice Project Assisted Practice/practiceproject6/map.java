package practiceproject6;
import java.util.*;
public class map {

	public static void main(String[] args) {
		
		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"Ram");    
	      hm.put(2,"Sham");    
	      hm.put(3,"Raj");   
	       
	      System.out.println("The elements of Hashmap are ");  
	      for(Map.Entry m:hm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(1,"Red");  
	      ht.put(2,"pink");  
	      ht.put(3,"blue");  
	      ht.put(4,"green");  

	      System.out.println("The elements of HashTable are ");  
	      for(Map.Entry n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	      //TreeMap
	      
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(1,"sita");    
	      map.put(2,"Gita");    
	      map.put(3,"Rita");       
	      
	      System.out.println("The elements of TreeMap are ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  
}


