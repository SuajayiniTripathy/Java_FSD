package practiceproject7;

public class innerclass {

	 private String msg="This is Sujayini"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", I am from odisha");}  
	 }  


	public static void main(String[] args) {

		innerclass obj=new innerclass();
		innerclass.Inner in=obj.new Inner();  
		in.hello();  
	}
}

