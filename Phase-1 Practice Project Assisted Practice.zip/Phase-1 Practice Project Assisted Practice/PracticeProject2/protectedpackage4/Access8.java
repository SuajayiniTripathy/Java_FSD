package protectedpackage4;

import publicpakage3.Access5;

public class Access8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Access7 a = new Access7();
		System.out.println(a.hours);
		System.out.println(a.minutes);

	}

}
