package protectedpackage4;

public class Access7 {

	protected int hours=3;
	protected int minutes= 40;

}
