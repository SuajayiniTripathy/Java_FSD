package privatepacakage2;

import package1.Access1;

public class Access4 {
	public static void main(String[] args) {
	Access3 a = new Access3();
	System.out.println(a.hours);
	System.out.println(a.minutes);
 }
}