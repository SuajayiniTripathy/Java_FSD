package privatepacakage2;

public class Access3 {
	int hours=3;
	private int minutes= 40;
	
	}


