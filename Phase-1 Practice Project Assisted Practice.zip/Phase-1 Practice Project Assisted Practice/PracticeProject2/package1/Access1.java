package package1;

public class Access1 {

	int hours=3;
	int minutes= 40;

	}


