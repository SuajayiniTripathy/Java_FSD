package publicpakage3;

import privatepacakage2.Access3;

public class Access6 {

	public static void main(String[] args) {
		Access5 a = new Access5();
		System.out.println(a.hours);
		System.out.println(a.minutes);

	}

}
