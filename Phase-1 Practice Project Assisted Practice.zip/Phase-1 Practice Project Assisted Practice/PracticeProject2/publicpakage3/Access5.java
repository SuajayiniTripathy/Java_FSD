package publicpakage3;

public class Access5 {

	public int hours=3;
	public int minutes= 40;
	}


