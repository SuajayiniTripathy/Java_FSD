package practiceproject3;

//without return type and with argument
public class persondetails4 {
	
	void incSalary(int salary, int bonus) {

		System.out.println("final amount is :" +(bonus+salary));
	}
}

