package practiceproject3;

//without return type and with argument
public class person4 {
	public static void main(String[] args) {
		persondetails4 persondetail=new persondetails4();
		persondetail.incSalary(50000,5000);
	}

}
