package practiceproject3;

//with return type and with argument
public class persondetails1 {
	
	int incSalary(int salary,int bonus) {
		return bonus+salary;
	}

}

