package practiceproject3;

//without return type and without argument
public class person3 {
	public static void main(String[] args) {
		persondetails3 persondetail=new persondetails3();
		persondetail.bonus=5000;
		persondetail.salary=50000;
		persondetail.incSalary();
	}

}
