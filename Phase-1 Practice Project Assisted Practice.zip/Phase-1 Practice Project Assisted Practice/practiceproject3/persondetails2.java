package practiceproject3;

//with return type and without argument
public class persondetails2 {
	int salary, bonus;
	int incSalary() {
		return bonus+salary;
	}

}
