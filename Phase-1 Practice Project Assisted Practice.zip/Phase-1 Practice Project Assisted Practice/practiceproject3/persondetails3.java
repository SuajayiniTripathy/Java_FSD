package practiceproject3;

//without return type and without argument
public class persondetails3{
	int salary, bonus;
	void incSalary() {

		System.out.println("final amount is :" +(bonus+salary));
	}

}

