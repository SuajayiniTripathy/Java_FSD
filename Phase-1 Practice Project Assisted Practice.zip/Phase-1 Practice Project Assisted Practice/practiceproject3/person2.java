package practiceproject3;

//with return type and without argument
public class person2 {
	public static void main(String[] args) {
		persondetails2 persondetail=new persondetails2();
		persondetail.bonus=5000;
		persondetail.salary=50000;
		int finalamount=persondetail.incSalary();
	System.out.println("final amount is :"+finalamount);
	}

}
