package practiceproject3;

//with return type and with argument
public class person1 {
	public static void main(String[] args) {
		persondetails1 persondetail=new persondetails1();
		int finalamount=persondetail.incSalary(50000, 5000);
	System.out.println("final amount is :"+finalamount);
	}

}



