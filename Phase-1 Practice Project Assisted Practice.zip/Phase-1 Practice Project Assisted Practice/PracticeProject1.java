//Implicit Casting
public class PracticeProject1 {

	public static void main(String[] args) {
		float price = 100.0F;
		int gst = 18 ;
		float finalPrice = price + gst;
		System.out.println(finalPrice);
// Explicit Casting
         int price1 =100;
         float gst1 =18F;
         int finalprice = price1 + (int)gst1;
         System.out.println(finalprice);
	}

}
