import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class InsertDAO {
	public int insert(Product p) {
		SessionFactory sf=config.hibConfig();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		int r=(int)s.save(p);
		t.commit();
		return r;
	}


public List<Product> get() {
	SessionFactory sf=config.hibConfig();
	Session s=sf.openSession();
	Transaction t=s.beginTransaction();
	Query q=s.createQuery("from employee");
	List<Product> Pl =q.list();
	t.commit();
	return Pl;
}
}
