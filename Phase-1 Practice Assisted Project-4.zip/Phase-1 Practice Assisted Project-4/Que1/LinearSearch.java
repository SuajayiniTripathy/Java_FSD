package Que1;

public class LinearSearch {

	public static void main(String[] args) {
		int array[] = {70, 20, 25, 18, 97, 57};
	      int size = array.length;
	      int value = 20;
	      for (int i=0 ;i< size-1; i++){
	         if(array[i]==value){
	            System.out.println("Element found ");
	         }else{
	            System.out.println("Element not found");
	         }
	      }
	   }
	

	}


