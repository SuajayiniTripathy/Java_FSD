package Que3;

import java.util.Arrays;

public class ExponentialSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int array[] = {3,70,48,20,50,79,68};
		   int searchValue = 48;
		   int result = expSearch(array, array.length, searchValue);
		   System.out.println("Element is present at index: " + result);
		  }
	static int expSearch(int array[], int n, int searchValue) {
		  if(array[0] == searchValue) {
		   return 0;
		  }
		  int i = 1;
		  while (i < n && array[i] <= searchValue) {
		   i = i * 2;
		  }
		  return Arrays.binarySearch(array, (i / 2), Math.min(i, n), searchValue);
		}
	
		
	}


