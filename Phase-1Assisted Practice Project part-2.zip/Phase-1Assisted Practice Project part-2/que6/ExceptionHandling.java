package que6;
import java. util.Scanner;
public class ExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner EH = new Scanner (System.in);
		 System.out.println("Enter two integer numbers");

		// Read two integer numbers.
		  int num1 = EH.nextInt();
		  int num2 = EH.nextInt();
		System.out.println(num1 + "/" + num2 + " = " + (num1/num2));
		  }
		

	}


