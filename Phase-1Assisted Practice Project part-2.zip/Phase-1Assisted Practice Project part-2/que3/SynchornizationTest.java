package que3;

public class SynchornizationTest {
	synchronized void printTable(int n){ 
		   for(int i=1;i<=5;i++){  
		     System.out.println(n*i);  
		     try{  
		      Thread.sleep(400);  
		     }catch(Exception e){System.out.println(e);}  
		   }  
		  
		 }  
		 
	public static void main(String[] args) {
		SynchornizationTest obj = new SynchornizationTest(); 
		  
		Thread t1=new Thread(){  
		public void run(){  
		obj.printTable(5);  
		}  
		};    
		t1.start();  
		 
		}  
		

	}


