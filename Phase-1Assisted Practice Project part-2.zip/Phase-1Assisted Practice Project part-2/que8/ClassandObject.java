package que8;

public class ClassandObject{
	String name; 
    int YOP; 
    String University; 
    public ClassandObject(String name, int Yop, String University) 
    { 
        this.name = name;  
        this.YOP = Yop; 
        this.University = University; 
    } 
    public String getName() 
    { 
        return name; 
    } 

    public int getYOP() 
    { 
        return YOP; 
    } 
    public String getUniversity() 
    { 
        return University; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ ".\nMy YOP is" +    this.getYOP() +" University is " + this.getUniversity() + "."); 
    } 
    public static void main(String[] args) 
    { 
    	ClassandObject scott = new ClassandObject("Sujayini Tripathy", 2022, "KIIT"); 
        System.out.println(scott.toString()); 
    } 
}