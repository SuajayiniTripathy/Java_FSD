package que8;

public class Encasulation {
	
			// privatevariable
			String name;
		
			// gettermethodforname
		String getName()
		{
			 return name;
			
		}
		
			// settermethodforname
			public void setName(String name)
		{
			 this.name = name;
		}
		
	


	// Javaclasstotesttheencapsulatedclass.
	
	
		 public static void main(String[]args){
		
			
				// creatinginstanceoftheencapsulatedclass
			 Encasulation car= new Encasulation();
			
				// settingvalueinthenamemember
				car.setName("Honda");
			
				// gettingvalueofthenamemember
				System.out.println(car.getName());
			
		}
		
	}
