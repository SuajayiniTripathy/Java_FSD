package que2;

public class Sleepandwait {
     private static Object Obj = new Object();
	public static void main(String[] args) throws InterruptedException  {
		  Thread.sleep(3000);
		  System.out.println(Thread.currentThread().getName()+"This thread is wokeup after some seconds");
		  synchronized (Obj)
		  {
			  Obj.wait(2000);   
			  
	            System.out.println(Obj + " Object is in waiting state and woken after 2 seconds");
		  }
		  

	}

}
