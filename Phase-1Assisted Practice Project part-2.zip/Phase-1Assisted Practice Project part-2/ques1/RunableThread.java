package ques1;

public class RunableThread implements Runnable {

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Thread has ended");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunableThread RT = new RunableThread ();
		Thread T1= new Thread ();
		T1.start();
		System.out.println("This is a new thread");
	}
}
