package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackDAO {
	@Autowired
	FedbackRepository repo;
	
	public Feedback insert(Feedback e) {
		return repo.save(e);
	}
	
	public List<Feedback> getall(){
		return repo.findAll();
	}
	
	
	public Feedback getbyid(int id) {
		return repo.getById(id);
	}
	
	public void delete(int id) {
		 repo.deleteById(id);
	}
		
	public Feedback updateByName(Feedback e) {
		
		Feedback ee=repo.findById(e.getUserid()).orElse(null);
		ee.setUsername(e.getUsername());
		return repo.save(ee);
		
	}
}


