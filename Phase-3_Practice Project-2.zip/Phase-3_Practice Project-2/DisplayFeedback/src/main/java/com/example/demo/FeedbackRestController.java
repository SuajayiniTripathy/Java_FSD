package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackRestController {
	@Autowired
	FeedbackDAO dao;
	
@PostMapping("/insert")
	public Feedback insert(@RequestBody Feedback e) {
		return dao.insert(e);
	}
@GetMapping("/getall")
public List<Feedback> getall(){
	return dao.getall();
}

}
