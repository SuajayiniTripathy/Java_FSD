public class emailValidation{
   static boolean isValidemail(String email) {
      String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";    //regex to validate email.
      return email.matches(regex);                  //match email id with regex and return the value
   }
   public static void main(String[] args) {
      String email = "tripathy.sujayini@gmail.com";
      System.out.println("The Email ID is: " + email);
      System.out.println("Email ID is valid? " + isValidemail(email));
       
      email = "@st@gmail.com";
      System.out.println("The Email ID is: " + email);
      System.out.println("Email ID is valid? " + isValidemail(email));
   }
}