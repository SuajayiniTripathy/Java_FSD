package Phase_5_EndProject.Automate_an_E_Commerce_Web_Application;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FilpKartTest {
WebDriver wd;
@BeforeTest
public void config() {
	WebDriverManager.chromedriver().setup();
	wd=new ChromeDriver();
	wd.manage().window().maximize();
	
}
	
	@Test
  public void flipkarttest() {
		 wd.get("https://www.flipkart.com/");
		 WebElement textbox=wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input"));
			textbox.sendKeys("iPhone 13");
			textbox.submit();
			JavascriptExecutor js= (JavascriptExecutor)wd;
			   js.executeScript("window.scrollBy(978,document.body.scrollHeight)");
	  }


  }

