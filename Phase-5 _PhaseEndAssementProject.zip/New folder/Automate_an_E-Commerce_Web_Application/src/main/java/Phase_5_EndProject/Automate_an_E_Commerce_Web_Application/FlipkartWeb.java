package Phase_5_EndProject.Automate_an_E_Commerce_Web_Application;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FlipkartWeb {
	
		public static void main(String[] args) {
			//register the chrome driver
			System.setProperty("webdriver.chrome.driver","G:\\95\\chromedriver.exe");
			WebDriver wd=new ChromeDriver();
			//maximize the screen
			wd.manage().window().maximize();
			//any website or any localhost
			wd.get("https://www.flipkart.com/");
			WebElement textbox=wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input"));
			textbox.sendKeys("iPhone 13");
			textbox.submit();
			//wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/button/svg")).click();
			//WebElement Product=wd.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div/a"));
			//Product.submit();
		    //scrolls the web page to the specific number of pixels.
		   JavascriptExecutor js= (JavascriptExecutor)wd;
		   js.executeScript("window.scrollBy(978,document.body.scrollHeight)");
		   

		}
}