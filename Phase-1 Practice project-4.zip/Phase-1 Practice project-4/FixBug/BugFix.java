package FixBug;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class BugFix {
	public static void main(String[] args) {
        System.out.println("  LABELS   ");
        optionsSelection();

    }
    private static void optionsSelection() {
        String[] arr = {"1. Dispaly My_list\n2. Add elements on My_list\n3. Sort My_list\n4. Exit"};
        int[] arr1 = {1,2,3,4};
        int  slen = arr1.length;
        for(int i=0; i<slen;i++){
            System.out.println(arr[i]);
        ArrayList<Integer> arrlist = new ArrayList<Integer>();
        ArrayList<Integer> My_list = new ArrayList<Integer>();
        My_list.add(120);
        My_list.add(300);
        My_list.add(600);
        My_list.addAll(arrlist);
        System.out.println("Choose your option");
        Scanner sc = new Scanner(System.in);
        int  options =  sc.nextInt();
        for(int j=1;j<=slen;j++){
            if(options==j){
                switch (options){
                    case 1:
                        System.out.println("Display My_list: ");
                        System.out.println(My_list+"\n");
                        optionsSelection();
                        break;
                    case 2:
                        System.out.println("Enter add value on My_list:");
                        int value = sc.nextInt();
                        My_list.add(value);
                        System.out.println("Recent My_list");
                        My_list.addAll(arrlist);
                        System.out.println(My_list+"\n");
                        optionsSelection();
                        break;
                    case 3:
                        sortExpenses(My_list);
                        optionsSelection();
                        break;
                    case 4:
                        Exit();
                        break;
                    default:
                        System.out.println("Invalid choice!");
                        break;
                }
            }
        }}

    }
    private static void Exit() {
    	 System.out.println("Now You are Exit");
		}
	
    private static void searchExpenses(ArrayList<Integer> arrayList) {
        int leng = arrayList.size();
        System.out.println("Enter the expense you need to search:");
        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        for(int i=0;i<leng;i++) {
        	if(arrayList.get(i)==input) {
        		System.out.println("Found the My_list " + input + " at " + i + " position");
        	}
        }
    }
    private static void sortExpenses(ArrayList<Integer> arrayList) {
        int arrlength =  arrayList.size();
        Collections.sort(arrayList);
        System.out.println("Sorted My_list: ");
        for(Integer i: arrayList) {
        	System.out.print(i + " ");
        }

        System.out.println("\n");

    }
}


